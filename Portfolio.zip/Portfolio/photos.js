WPGgallery = new Object();
WPGgallery.name = "Adobe%20Web%20Photo%20Gallery";
WPGgallery.photographer = "";
WPGgallery.contact = "";
WPGgallery.email = "";
WPGgallery.date = "1/11/2012"

WPGgallery.colors = new Object();
WPGgallery.colors.background = "#FFFFFF";
WPGgallery.colors.banner = "#F0F0F0";
WPGgallery.colors.text = "#000000";
WPGgallery.colors.link = "#0000FF";
WPGgallery.colors.alink = "#FF0000";
WPGgallery.colors.vlink = "#800080";

gPhotos = new Array();
gPhotos[0] = new Object();
gPhotos[0].filename = "Collisium.jpg";
gPhotos[0].ImageWidth = 650;
gPhotos[0].ImageHeight = 487;
gPhotos[0].ThumbWidth = 75;
gPhotos[0].ThumbHeight = 56;
gPhotos[0].meta = new Object();

gPhotos[1] = new Object();
gPhotos[1].filename = "Collisium2.jpg";
gPhotos[1].ImageWidth = 650;
gPhotos[1].ImageHeight = 487;
gPhotos[1].ThumbWidth = 75;
gPhotos[1].ThumbHeight = 56;
gPhotos[1].meta = new Object();

gPhotos[2] = new Object();
gPhotos[2].filename = "futuristic%20city1.jpg";
gPhotos[2].ImageWidth = 650;
gPhotos[2].ImageHeight = 487;
gPhotos[2].ThumbWidth = 75;
gPhotos[2].ThumbHeight = 56;
gPhotos[2].meta = new Object();

gPhotos[3] = new Object();
gPhotos[3].filename = "mayapic2.jpg";
gPhotos[3].ImageWidth = 650;
gPhotos[3].ImageHeight = 487;
gPhotos[3].ThumbWidth = 75;
gPhotos[3].ThumbHeight = 56;
gPhotos[3].meta = new Object();

gPhotos[4] = new Object();
gPhotos[4].filename = "pumpkin2.jpg";
gPhotos[4].ImageWidth = 650;
gPhotos[4].ImageHeight = 487;
gPhotos[4].ThumbWidth = 75;
gPhotos[4].ThumbHeight = 56;
gPhotos[4].meta = new Object();

gPhotos[5] = new Object();
gPhotos[5].filename = "spacestationpic.jpg";
gPhotos[5].ImageWidth = 650;
gPhotos[5].ImageHeight = 487;
gPhotos[5].ThumbWidth = 75;
gPhotos[5].ThumbHeight = 56;
gPhotos[5].meta = new Object();

gPhotos[6] = new Object();
gPhotos[6].filename = "warehouse3.jpg";
gPhotos[6].ImageWidth = 650;
gPhotos[6].ImageHeight = 365;
gPhotos[6].ThumbWidth = 75;
gPhotos[6].ThumbHeight = 42;
gPhotos[6].meta = new Object();

